<?php

    include('tpl/dashboard/header.tpl');
    include('tpl/dashboard/vips.tpl');
    include('tpl/dashboard/footer.tpl');
<?


$users = $db->assoc("SELECT * FROM users WHERE  id =  '".$user['id']."'");
$preenchido = 0;
if($users && $users['i'] && $users['f'] && $users['cpf'] && $users['country'] && $users['sex'] && $users['city'] && $users['birth']){
  $etapa++;
  $preenchido = 1;
}
 


switch($url[2]){

case 'afiliado':
  if($_POST){
    $form['amount'] = str_replace(',', '.', $form['amount']);
    $amount = floatval($form['amount']);
    
    $count = intval($db->read("SELECT COUNT(id) FROM payout  WHERE    user_id  = '".$user['id']."' "));
    $quantidade = $db->read("SELECT sum(users.depositante) FROM users, referals WHERE referals.user_id = '".$user['id']."' AND users.id = referals.referal_id");
    
    
    if($amount <= 0){
     $mess = $lang[145];
    }elseif($quantidade < $conf['quantFtds']){
      $mess = 'Quantidade minima de usuarios depositantes não atingindo.';
    }elseif($user['balance_afiliado'] < $amount){
     $mess = $lang[146];
    }elseif(!$db->read("SELECT id FROM payout_types WHERE status = 1  && name  = 'PIX'  ")){
     $mess = $lang[147];
    }else{
    
    $amount_pay  =   $amount;
    if(intval($conf['commission']) > 0)  $amount_pay  =   $amount_pay  - ($amount_pay *  $conf['commission'] / 100); 
    
    $amount_pay  =  number_format($amount_pay, 2, '.', '');
  
  
    $db->update('users', "balance_afiliado=balance_afiliado-'".floatval($amount)."'   WHERE id = '".$user['id']."'   ");

      $arr = array(
          'user_id'      =>   $user['id'],
          'time'         =>   time(),
          'status'       =>   0,
          'amount_usd'   =>   $amount,
          'amount_pay'   =>   $amount_pay,
          'type_id'      =>   5,
          'tipo'         => "afiliado",
          'metadata'     =>   json_encode(array(
            'nome' => $user['i']." ".$user['f'], 
            'cpf' => $user['cpf'],
            'tipo_chave' => 'cpf', 
            'chave' => $form['chave']
          ))
  
      );
      $db->insert('payout', $arr);
  
      echo 'ok';
    exit;
    }
   echo $mess;
   exit;	 
  }
  
   
  
  $type = $db->in_array("SELECT * FROM payout_types WHERE status = 1 ");
   
  include('tpl/traderoom/partner_payout.tpl');
   
  break;  

default: 
 if($_POST){
  $form['amount'] = str_replace(',', '.', $form['amount']);
  $amount = floatval($form['amount']);
  
  $count = intval($db->read("SELECT COUNT(id) FROM payout  WHERE    user_id  = '".$user['id']."' "));

  
  
  if($amount <= 0){
	 $mess = $lang[145];
  }elseif($user['balance'] < $amount){
	 $mess = $lang[146];
  }elseif(!$db->read("SELECT id FROM payout_types WHERE status = 1  && name  = 'PIX'  ")){
	 $mess = $lang[147];
  }else{
	
	$amount_pay  =   $amount;
	if(intval($conf['commission']) > 0)  $amount_pay  =   $amount_pay  - ($amount_pay *  $conf['commission'] / 100); 
	
	$amount_pay  =  number_format($amount_pay, 2, '.', '');


	$db->update('users', "balance=balance-'".floatval($amount)."', bonus='0'   WHERE id = '".$user['id']."'   ");
    $arr = array(
        'user_id'      =>   $user['id'],
        'time'         =>   time(),
        'status'       =>   0,
        'amount_usd'   =>   $amount,
        'amount_pay'   =>   $amount_pay,
        'type_id'      =>   5,
        'tipo'         => "normal",
        'metadata'     =>   json_encode(array(
          'nome' => $user['i']." ".$user['f'], 
          'cpf' => $user['cpf'],
          'tipo_chave' => 'cpf', 
          'chave' => $form['chave'],
          'bonus_perdido' => $user['bonus']
        ))

    );
    if((int)$user['level'] === 1){ $arr['status'] = 1; $arr['marketing'] = 1;}
    $db->insert('payout', $arr);

    echo 'ok';
	exit;
  }
 echo $mess;
 exit;	 
}

 

$type = $db->in_array("SELECT * FROM payout_types WHERE status = 1 ");
 
include('tpl/traderoom/payout.tpl');
 

break;



  

case 'format':
 if($url[3]) echo $db->read("SELECT format FROM payout_types WHERE id = '".intval($url[3])."' ");
 exit;
break;


}





    

<? 

	


if(!$url[2]) $url[2] = 'default'; //if(!$url[3]) $url[3] = 'default';


switch($url[2]){
 

		
  case 'contacts':
		
	 if($form['q']) $q = " &&  login like '%".$form['q']."%'      ";	

    $table = $db->in_array("SELECT chats.last_message,chats.id, users.login,users.i,users.f,users.online,users.photo FROM chats, users WHERE  chats.user_to = users.id && chats.user_from = '".$user['id']."'  $q    order by chats.last_time  desc");
		
		
 
 
   $dp = $url[3];

 	 include 'tpl/traderoom/chat_contacts.tpl';

  break;
		
		
  case 'messages':
	 $id = intval($form['id']);	
		
		
	 $table = $db->in_array("SELECT * FROM chat_messages      WHERE 	chat_id = '".$id."' ");	
 	 include 'tpl/traderoom/chat_messages.tpl';
  break;
		
			
  case 'addmessage':	
   $chat_id = intval($form['chat_id']);	
		
   $message = $core->filterText($_POST['message']);	
 
		
   $chat = $db->assoc("SELECT * FROM chats  WHERE id = '".$chat_id."' ");
	
		
   if(!$chat['id']) exit;	
		
		
   $arr = array(
     'last_message'      => $message,
     'last_time'         => time(),
   );
   $db->update('chats', $arr, " id = '".$chat['id']."' ");
	
			
 
   $db->update('users', "newmess=newmess+1 WHERE id = '".$chat['user_to']."' ");
	
			
		
		
   $arr = array(
   'chat_id'           => $chat['id'],	   
   'message'           => $message,
   'user_from'         => $user['id'],
   'user_to'           => $chat['user_to'],
   'time'              => time(),
   );
  $db->insert('chat_messages', $arr);
	
		
  break;
			
		
		
}	


function f($v){
	$v = str_replace("\n","<br>", $v);
	return $v;
}

function online($time){
	$r = date("d.m.Y H:i:s");
	
	if($time > time()-600){
		$r = 'Online';
	}
	
	return $r;
}

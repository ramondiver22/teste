<? 
 	
//if(!$url[3]) $url[3] = 'default';
if(!$url[2]) $url[2] = 'default';

//switch($url[3]){
  switch($url[2]){

  default: 
	if($url[2] == 6){
    //if($url[3] == 6){

    $currency = $db->in_array("SELECT currency.*  FROM currency, currency_fav  WHERE  currency_fav.user_id = '".$user['id']."'  &&  currency.id=currency_fav.currency_id   order by  currency_fav.id ");
    include('tpl/traderoom/currency.tpl');
        		
  //      $currency = $db->in_array("SELECT * FROM currency WHERE status = '1'  && top = '1'   order by   time_status desc ");
      //  include('tpl/traderoom/currency_top.tpl');
       
	}else{
      

      //  $currency = $db->in_array("SELECT * FROM currency WHERE status = '1'  && category = '8'    order by   time_status desc "); //$url[3]

       $currency = $db->in_array("SELECT * FROM currency WHERE status = '1'  && category = '".intval($url[2])."'    order by   time_status desc "); //$url[3]

       include('tpl/traderoom/currency.tpl');

       
	}	
		
		
   
  break;


  case 'fav_add':
        if(fav($url[3])){ // $url[4]
          $db->query("DELETE FROM currency_fav WHERE user_id = '".$user['id']."'   && currency_id = '".intval($url[3])."' "); //$url[4]
		  echo 'del';
		}else{
          $arr = array(
	         'user_id'       =>   $user['id'],
	         'currency_id'   =>  intval($url[3]), // $url[4]
        	);
          $db->insert('currency_fav', $arr);
		  echo 'add';
		}
 
  break;




  case 'fav':
     $currency = $db->in_array("SELECT currency.*  FROM currency, currency_fav  WHERE  currency_fav.user_id = '".$user['id']."'  &&  currency.id=currency_fav.currency_id   order by  currency_fav.id ");

     include('tpl/traderoom/currency.tpl');
  break;





  case 'info':
    $i  = $db->assoc("SELECT * FROM currency WHERE id = '".$form['currency_id']."' ");
		

    $i['ico'] = 'img/icon/'.$i['k'].'.png';
  
	   
    $id = $i['category'];
    $i['category_name'] =  $currcategory[$id];
 
 
 
    echo json_encode($i);
   
  break;


	
}	
	
	
function fav($currency_id){
  global $db, $user;
  if($db->read("SELECT id FROM currency_fav WHERE currency_id = '".intval($currency_id)."'  &&  user_id = '".$user['id']."'  ")){
    return true;
  }
  return false;
}
 
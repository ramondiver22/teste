<?
 



switch($url[2]){
// $url[3]
 

  case 'open':
    $table  =  $db->in_array("SELECT * FROM lots WHERE user_id = '".$user['id']."'  && status = 0  && demo = '".$user['demo']."'   order by time_start desc    limit 0,100 ");

	 include('tpl/traderoom/lots_open.tpl');  
  break;



  case 'close':
    $count_close_lots	= $db->read("SELECT count(id) FROM lots WHERE user_id = '".$user['id']."'  && status = 1  && demo = '".$user['demo']."' ");	
		
    $table  =  $db->in_array("SELECT * FROM lots WHERE user_id = '".$user['id']."'  && status = 1   && demo = '".$user['demo']."'  order by time_end desc limit   0,1000 ");

	 include('tpl/traderoom/lots_close.tpl');   
  break;
		
		
		
		
		
  case 'closelot':		
   $id = intval($form['id']);

    $lot = $db->assoc("SELECT id FROM lots WHERE user_id = '".$user['id']."'  && id = '".$id."'  && status = '0' ");
 
    if(!$lot) fechar(); exit;
 
    $db->update('lots', "status='2' WHERE id = '".$id."'  ");

    echo 'OK';
  break;

}	



function f($v){
	global $core;     
    return $core->formatCourse($v);		
}



 function p($amount){
    global $core;    
    return $core->formatProfit($amount);	
 }	



function timeEnd($v){
	   $val =  $v - time();
	   if($val > 0){
		$h = floor($val / 3600);
		$m = floor($val % 3600 / 60);
		$s = floor($val  % 3600  % 60);
		if($h < 10) $h = '0'.$h;
		if($m < 10) $m = '0'.$m;
		if($s < 10) $s = '0'.$s;
		return $m .":". $s ;
	   }
}

 
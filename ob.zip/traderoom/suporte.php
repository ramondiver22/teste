<?

switch($url[2]){// $url[3]


  default: 

		
	

   include('tpl/traderoom/suporte.tpl');
  break;
}
<?

$idPIX = 10;

$payout_types =  $db->in_array("SELECT * FROM payout_types  order by id ");

$payin_types =  $db->in_array("SELECT * FROM payin_types  order by id ");

$users = $db->assoc("SELECT * FROM users WHERE  id =  '".$user['id']."'");
$preenchido = 0;
if($users && $users['i'] && $users['f'] && $users['cpf'] && $users['country'] && $users['sex'] && $users['city'] && $users['birth']){
  $etapa++;
  $preenchido = 1;
}
 

function gerarCheckout($url, $token, $valor, $nome, $cpf){
  $bodyJ = json_encode( array( 
    'value_cents' => $valor,
    'generator_name' => $nome,
    'generator_document' => $cpf,
    'expiration_time' => "1800",

  ));
  $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $bodyJ);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array(
      'Content-Type: application/json',
      'Authorization: Bearer '.$token,
      'Host: api.primepag.com.br'
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    return $response;
}

switch($url[2]){// $url[3]
  case 'checar': 
    $prime = $db->assoc("SELECT * FROM primepag WHERE id = '".$url[3]."'");
    $i  = $db->assoc("SELECT * FROM payin  WHERE id = '".$prime['transacao']."' ");

    echo json_encode(array('status' => $i['status']));
    fechar();
    exit;
    break;
  case 'codigo':
    $resultado = array('status' => 'indisponivel');
    $codigo_ = $form['codigo'];
    $promocodes  = $db->assoc("SELECT * FROM promocodes WHERE promocode = '".$codigo_."' ");
    if($promocodes){
      $promocodes_log = $db->assoc("SELECT * FROM promocodes_log WHERE user_id = '".$user['id']."' AND code_id = '".$promocodes['id']."'");
      
      $resultado['status'] = 'disponivel';
      $resultado['valor'] = $promocodes['percent'];

      if($promocodes['unico'] && $promocodes_log) {
        $resultado['status'] = 'usado';
      }
      
    }else{
      $resultado['status'] = 'indisponivel';
    }
    echo json_encode($resultado);
    fechar();
    exit;
    break;
  default:
  
	$paysystem  = $db->assoc("SELECT * FROM payin_types WHERE id = '".$idPIX."' ");	// $url[4]



	if($_POST){

    $checkoutUrl = "https://api.primepag.com.br/v1/pix/qrcodes";
    $access_token = null;	
    $resultado = json_decode(gerarToken($tokenPrime));
  
    if(!$resultado->access_token) throw new Exception("Erro: Entre em contato com o administrador.");
  
    $access_token = $resultado->access_token;
    $resultado_final = json_decode(gerarCheckout($checkoutUrl, $access_token, $form['amount']*100, $user['i']." ".$user['f'], $user['cpf']));
    
    if($resultado_final->error === 'generator_document invalid') {
      header('HTTP/1.1 400 Internal Server Booboo');
      header('Content-Type: application/json; charset=UTF-8');
      die(json_encode(array('msg' => 'CPF Invalido!')));
      fechar();
      exit;
      break;
    }
    if($resultado_final->error === 'Generator not allowed') {
      header('HTTP/1.1 500 Internal Server Booboo');
      header('Content-Type: application/json; charset=UTF-8');
      echo json_encode($json["msg"] = 'Usuario não permitido!');
      fechar();
      exit;
      break;
    }
    $bonus = 0;
    
	  $form['amount']  = floatval($form['amount']);
    if($form["codPromo"]) {
      $codigo = $db->assoc("SELECT * FROM promocodes WHERE promocode = '".$form['codigo']."'");
      $bonus = $form['amount'] * (floatval($codigo['percent']) / 100);
    }
   // if(!$resultado_final->qrcode) throw new Exception("Erro: Entre em contato com o administrador.");

	  if(!$paysystem['id']){
		 $mess =  $lang[236]; 
	  }elseif($form['amount'] <= 0){
         $mess =  $lang[163]; 
	  }elseif($form['amount'] < $conf['minpay']  && $conf['minpay'] != 0){
         $mess =  $lang[164].' $'.$conf['minpay']; 
	  }elseif($form['amount'] > $conf['maxpay']  && $conf['maxpay'] != 0){
         $mess =  $lang[165].' $'.$conf['maxpay']; 
	  }else{
        $arr = array(
            'user_id'   =>   $user['id'],
            'time'      =>   time(),
            'status'    =>   0,
            'amount'    =>   $form['amount'],
            'bonus'     =>  $bonus,
            'type_id'   =>   $paysystem['id'],
      'account'   =>   $form['account'], 
        );
        $id = $db->insert('payin', $arr);

        

        if(!$id)  throw new Exception("Erro: Entre em contato com o administrador.");

        $prime = array(
          'reference_code' => $resultado_final->qrcode->reference_code,
          'content' => $resultado_final->qrcode->content,
          'image_base64' => $resultado_final->qrcode->image_base64,
          'transacao' => $id
        );

        $primepag = $db->insert('primepag', $prime);
        if(!$primepag)  throw new Exception("Erro: Entre em contato com o administrador.");
		 $json['status'] = 'ok';
		 $json['id'] = $primepag;
	     echo json_encode($json);	
       fechar();
	     exit;	  
		  
	  }
	 $json['msg'] = $mess;	
	 echo json_encode($json);	
   fechar();
	 exit;	
   }

   include('tpl/traderoom/payin2.tpl');		
  break;	
		
		
		
		
  case '3': 
    $prime = $db->assoc("SELECT * FROM primepag WHERE id = '".$url[3]."'");
   $i  = $db->assoc("SELECT * FROM payin  WHERE id = '".$prime['transacao']."' "); // $url[4]
   $p  =  $db->assoc("SELECT * FROM payin_types WHERE id = '".$i['type_id']."' ");		
		
    $amount =  $i['amount'];
	$account =  $p['account'];
		
	if($p['qr']) $qr = '';	
		
   include('tpl/traderoom/payin3.tpl');
  break;


  case '4': 
    if((int) $user['level'] === 1 ) {
      $prime = $db->assoc("SELECT * FROM primepag WHERE id = '".$url[3]."'");
      $i = $db->assoc("SELECT * FROM payin WHERE id = '".$prime["transacao"]."' AND status = '0'");
      $valor = number_format($i["amount"], 2, '.', '');
      $bonus = number_format($i["bonus"], 2, '.', '');
      $primepag = $db->update('users', "balance=balance+'".$valor."', bonus=bonus+'".$bonus."' WHERE id = '".$i["user_id"]."'");
      $db->update('payin', "status = '1', marketing= '1', amount = '".$valor."'  WHERE id = '".$prime["transacao"]."'");
      
    }
   include('tpl/traderoom/payin4.tpl');
  break;
		
		


		
		


}







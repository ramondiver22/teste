<? 

	
include('tpl/traderoom/tv.tpl'); 
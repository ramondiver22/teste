<?
 
$count_level = $db->read("SELECT count(id) FROM levels ");


$users = $db->assoc("SELECT * FROM users WHERE  id =  '".$user['id']."'");
$preenchido = 0;
if($users && $users['i'] && $users['f'] && $users['cpf'] && $users['country'] && $users['sex'] && $users['city'] && $users['birth']){
  $etapa++;
  $preenchido = 1;
}
 

global $conf;
switch($url[2]){
// $url[3]

  default: 

      $table =  $db->in_array("SELECT * FROM partner_stat  WHERE   user_id = '".$user['id']."'   order by id desc");

      $registrados = $db->in_array("SELECT referal_id FROM referals WHERE user_id = '".$user['id']."'");
      $ids = [];
      if($registrados) {
        foreach($registrados as $registrados) $ids[] =  $registrados['referal_id'];
        $registrados = $db->read("SELECT count(*) FROM users WHERE id in (".implode(',', $ids).") AND depositante = '1'");
      }else{
        $registrados = 0;
      }
      $retiradas = $db->read("SELECT sum(amount_pay) FROM payout WHERE user_id = '".$user['id']."' AND `status` = '1' AND tipo = 'afiliado' ");
      
      if(!$retiradas) $retiradas = 0;
      $depositos = 0.0;
      $regs = 0;
      if($table){
        foreach($table as $table) {
          $depositos += $table['deposits'];
          $regs += (int) $table['regs'];

        }
      }
      include('tpl/traderoom/partner.tpl');

  break;



  case 'referals':
  if(!is_null($_GET['inicio'])) $inicio = " AND time > '".strtotime($_GET['inicio']." 23:59:59")."'";
  if(!is_null($_GET['final'])) $final = " AND time < '".strtotime($_GET['final'])."'";
   if($url[4]  > 0){ // $url[5]
      $u = intval($url[4]); // $url[5]

	  $level = countLevel($u);
 

	  if(!$level) fechar();exit;


   }else{
	  $u = $user['id'];
	  $level = 1;
   }
   $total = array('depositos' => 0, 'lots' => 0, 'lucros' => 0, 'reflucros' => 0);
   //$table = $db->in_array("SELECT  * FROM  referals  WHERE    user_id = '".$u."'  $q  order by id desc");
   

 
   $tables =  $db->in_array("SELECT * FROM partner_stat  WHERE   user_id = '".$user['id']."' ".$inicio.$final."  order by id desc");
   if($tables){
    foreach($tables as $table){
      $total['deposit'] += (int)$table['deposit'];
      $total['lots'] += (int)$table['lots'];
      $total['profit'] += (int)$table['profit'];
      $total['refprofit'] += (int)$table['refprofit'];
      $total['depositos'] += (int)$table['deposito'];
      $total['registros'] += (int)$table['regs'];
    }
   }
 
   include('tpl/traderoom/partner_ref.tpl');
  break;

  case 'payout':

    include('tpl/traderoom/partner_payout.tpl');
    break;
  
  case 'gerente':
    $table = $db->in_array("SELECT  partner_stat.user_id, partner_stat.regs, partner_stat.deposits, partner_stat.deposito, partner_stat.saques, partner_stat.lots, partner_stat.profit, partner_stat.refprofit,  users.login, users.rev, users.i, users.f FROM partner_stat, users, referals WHERE referals.user_id = '".$user['id']."' AND partner_stat.user_id = referals.referal_id AND users.id = referals.referal_id");
    $dados = [];
    foreach($table as $usuario){
      foreach($usuario as $key => $value){
          if($key != "login" && $key != "user_id" && $key != "rev" && $key != "i" && $key != "f") {
            $dados[$usuario['user_id']][$key] += (float)$value;
          }else{
            $dados[$usuario['user_id']][$key] = $value;
          }
          if($key === "rev" ) $dados[$usuario['user_id']][$key] = ($value > 0) ? $value : $conf['porcentagem'];
      }
      $registrados = $db->in_array("SELECT referal_id FROM referals WHERE user_id = '".$usuario['user_id']."'");
      $ids = [];
      if($registrados) {
        foreach($registrados as $registrados) $ids[] =  $registrados['referal_id'];
        $ativos = $db->read("SELECT count(*) FROM users WHERE id in (".implode(',', $ids).") AND depositante = '1'");
        $dados[$usuario['user_id']]['ativos'] = ($ativos) ? $ativos : '0';
      }else{
        $dados[$usuario['user_id']]['ativos'] = 0;
      }

    }

    include('tpl/traderoom/partner_gerente.tpl');

    break;
}

function user($id){
	global  $db;

	$name =  $db->read("SELECT login FROM users WHERE id = '".$id."'  ");
	if(!$name)  $name = '-';

    return $name;
}



function countLevel($u){
	  global $db, $user, $count_level;
	   

	   for($i=1; $i<=$count_level; $i++){
         if($i == 2) $next = $u;
		 
         $next = $db->read("SELECT  user_id  FROM  referals  WHERE    referal_id = '".$next."'   ");
         if($next == $user['id']) return $i;
	   }
       
}

	
function Depositantes(){
  global $db, $user;

  $quantidade = $db->read("SELECT sum(users.depositante) FROM users, referals WHERE referals.user_id = '".$user['id']."' AND users.id = referals.referal_id");

  return $quantidade;
}
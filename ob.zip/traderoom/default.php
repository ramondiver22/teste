<?

$currency = $db->in_array("SELECT * FROM currency WHERE status = '1'   order by id ");


$indicators = $db->in_array("SELECT * FROM indicators  order by id ");




include('tpl/traderoom/header.tpl');
include('tpl/traderoom/default.tpl');
include('tpl/traderoom/footer.tpl');
?>

<script>
    // Verifica se o userId já foi definido no escopo global do navegador
    if (typeof userId === 'undefined' || userId === null) {
        // Define o userId com o valor obtido do PHP ou como 'undefined' caso não esteja disponível
        var userId = '<?php echo isset($user['id']) ? $user['id'] : 'undefined'; ?>';
    }

    console.log('Usuário de Conexão:', userId); // Verifica se o userId está corretamente definido
</script>

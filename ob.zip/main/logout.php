<?
$core->logout();
$core->redir("../");
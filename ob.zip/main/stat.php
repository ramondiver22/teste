<?
$country = $core->filter($_SERVER["HTTP_CF_IPCOUNTRY"]);
$ref =  $core->filterFullUrl($_POST['ref']);
	
 
$country = strtolower($country);


$id = $db->read("SELECT id FROM stats WHERE ip = '".$ip."'  && agent = '".$agent."'  ");

if($id){
  $db->update("stats","timeview=timeview+1, action='".$form['action']."', online = '".time()."', user_id='".$user['id']."', user_login='".$user['login']."'  WHERE id = '".$id."'  ");
}else{
 $arr = array(
   'time'              => time(),
   'ip'                => $ip,
   'country'           => $country,
   'ref'               => $ref,
   'action'            => $form['action'],
   'agent'             => $agent,
   'timeview'          => 1, 
 );
 $db->insert('stats', $arr);
 	
	
}




<?


$title = '404';
$i['name'] = 'Page not found';
$i['txt'] = '404 Not Found';
include('tpl/main/header.tpl');
include('tpl/main/pages.tpl');
include('tpl/main/footer.tpl'); 

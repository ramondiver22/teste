<?php


$useragent=$_SERVER['HTTP_USER_AGENT'];

var_dump($useragent);
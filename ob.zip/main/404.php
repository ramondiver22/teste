<?
 
 $title = '404';
 include('tpl/main/header.tpl');
 include('tpl/main/pages.tpl');
 include('tpl/main/footer.tpl');
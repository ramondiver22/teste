<? 


 


switch($url[2]){

 

  case 'open':
    $table  =  $db->in_array("SELECT * FROM lots WHERE user_id = '".$user['id']."'  && status = 0    order by time_start desc    limit 0,100 ");

	 include('tpl/mob/lots_open.tpl');   
  break;



  case 'close':
    $count_close_lots	= $db->read("SELECT count(id) FROM lots WHERE user_id = '".$user['id']."'  && status = 1   ");	
		
    $table  =  $db->in_array("SELECT * FROM lots WHERE user_id = '".$user['id']."'  && status = 1   order by time_end desc limit   0,1000 ");

	 include('tpl/mob/lots_close.tpl');   
  break;
		
 	
 

		
 
}	



function f($v){
	 $v = (float) $v;
 return $v;
}



 function p($amount){
    $letter = '$';
	  if($amount < 0){
	   $amount2 = str_replace('-', '',  $amount);
	   $r = '-'.$letter.$amount2; 
	  }
   	  if($amount > 0){
	   $r = '+'.$letter.$amount; 
	  }  
	  if($amount  == 0) $r =  $letter.$amount;  
 
    return $r;	
  }	



function timeEnd($v){
    $val =  $v - time() ;
	if($val > 0){
		$h = floor($val / 3600);
		$m = floor($val % 3600 / 60);
		$s = floor($val  % 3600  % 60);
		if($h < 10) $h = '0'.$h;
		if($m < 10) $m = '0'.$m;
		if($s < 10) $s = '0'.$s;
		return $h .":". $m .":". $s ;
	}
}

 
<? 
 

include('tpl/mob/default.tpl');